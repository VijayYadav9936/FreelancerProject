/**
 * Homepage component
 * Provides ability to add/edit/remove todos for today
*/

import { LightningElement, track, api } from "lwc";
export default class MainContainer extends LightningElement
 {
    // standard public property to get component size
    // value can be SMALL, MEDIUM, LARGE based on current context
    @api flexipageRegionWidth;

    //reactive properties for time and greeting
    @track time = "8:22 AM";
    @track greeting = "Good Morning";


    connectedCallback() {
        //get current time
        this.getTime();
        //get time periodically after every minute
        setInterval(() => {
            this.getTime();
        }, 1000 * 60);


    }

    /**
     * Get time and parse in human readable format
     * It follows 12 hour format
     */
    getTime() {
        const date = new Date(); /* creating object of Date class */
        const hour = date.getHours();
        const min = date.getMinutes();
        this.time = `${this.getHour(hour)}:${this.getDoubleDigit(
            min)} ${this.getMidDay(hour)}`;
        //get greeting (morning/afternoon/evening/)
        this.setGreeting(hour);
    }

   
    //Convert 24 hours format to 12 hours format
    getHour(hour) {
        return hour == 0 ? 12 : hour > 12 ? hour - 12 : hour;
    }

    //convert single digit to double digit
    getDoubleDigit(digit) {
        return digit < 10 ? "0" + digit : digit;
    }

    //return AM or PM based on current hour
    getMidDay(hour) {
        return hour >= 12 ? "PM" : "AM";
    }

    //return greeting based on current hour
    setGreeting(hour) {
        if (hour < 12) {
            this.greeting = "Good Morning";
        } else if (hour >= 12 && hour < 17) {
            this.greeting = "Good Afternoon";
        } else {
            this.greeting = "Good Evening";
        }
    }



}




 //Clock js