import { LightningElement, track } from 'lwc';
import SubmitClientAction from '@salesforce/apex/clientFeebackController.SubmitClientAction';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import {NavigationMixin} from 'lightning/navigation';


export default class FeedbackLWC extends LightningElement {

    @track clientObjFeedback;
    @track clientRecoreId;

    clientHandleChange(event){
        if(event.target.name == 'clientFeedback'){
          this.clientObjFeedback = event.target.value;  
        
        }
    }

    submitAction(){
        SubmitClientAction({cardFeedback : this.clientObjFeedback}) 
        // 
        .then(result=>{
            this.clientRecoreId = result.Id;
            window.console.log('clientRecoreId ' + this.clientRecoreId);       
            const toastEvent = new ShowToastEvent({
                title:'Success!',
                message:'Record created successfully',
                variant:'success'
              });
            this.dispatchEvent(toastEvent);
            this.clientObjFeedback = '';
            this.template.querySelector('lightning-input[data-name="clientFeedback"]').value = null;
    
        })
        .catch(error =>{
           this.errorMsg=error.message;
           window.console.log(this.error);
        });
    
     }
}