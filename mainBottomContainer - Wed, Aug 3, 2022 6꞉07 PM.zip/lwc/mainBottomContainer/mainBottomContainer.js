import { LightningElement } from 'lwc';

import Facebook from '@salesforce/resourceUrl/Facebook';
import Twitter from '@salesforce/resourceUrl/Twitter';
import Instagram from '@salesforce/resourceUrl/Instagram';
import Linkedin from '@salesforce/resourceUrl/Linkedin';



export default class MainBottomContainer extends LightningElement {
Facebooklogo = Facebook;
Twitterlogo = Twitter;
Instagramlogo = Instagram;
Linkedinlogo = Linkedin;
}